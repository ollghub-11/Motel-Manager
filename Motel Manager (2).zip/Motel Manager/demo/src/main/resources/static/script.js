document.getElementById("bookingForm").addEventListener("submit", async (event) => {
  event.preventDefault(); // Prevent the default form submission behavior

  // Collect form data
  const formData = {
    name: document.getElementById("name").value,
    age: document.getElementById("age").value,
    address: document.getElementById("address").value,
    idType: document.getElementById("idType").value,
    idNumber: document.getElementById("idNumber").value,
    email: document.getElementById("email").value,
    phone: document.getElementById("phone").value,
    checkin: document.getElementById("checkin").value,
    checkout: document.getElementById("checkout").value,
    room: document.getElementById("room").value,
    guests: document.getElementById("guests").value,
  };

  // Validate form data (simple example)
  const errors = [];
  if (!formData.name) errors.push("Name is required.");
  if (!formData.email) errors.push("Email is required.");
  if (!formData.phone) errors.push("Phone number is required.");
  if (!formData.checkin) errors.push("Check-in date is required.");
  if (!formData.checkout) errors.push("Check-out date is required.");
  if (!formData.room) errors.push("Room type is required.");
  if (!formData.guests || formData.guests < 1) errors.push("Number of guests must be at least 1.");

  if (errors.length > 0) {
    alert("Please fix the following errors:\n" + errors.join("\n"));
    return; // Exit function if there are validation errors
  }

  // Send data to backend
  try {
    const response = await fetch("http://your-server-endpoint/submit-booking", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    });

    const result = await response.json();
    if (result.success) {
      alert("Booking successful!");
    } else {
      alert("Booking failed: " + result.error);
    }
  } catch (error) {
    console.error("Error:", error);
    alert("An unexpected error occurred.");
  }
});