package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MotelManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MotelManagerApplication.class, args);
		System.out.println("Completed Buddy...");
	}

}
