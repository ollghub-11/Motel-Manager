package com.example.demo.controller;

import com.example.demo.entity.Booking;
import com.example.demo.Service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping
    public ResponseEntity<String> createBooking(@RequestBody Booking booking) {
        // Additional validation if needed
        booking.setCheckin(new Date()); // For example, use the current date for check-in
        booking.setCheckout(new Date()); // Similarly for checkout (use actual data for real use case)

        bookingService.saveBooking(booking);
        return ResponseEntity.ok("Booking successfully created!");
    }
}
